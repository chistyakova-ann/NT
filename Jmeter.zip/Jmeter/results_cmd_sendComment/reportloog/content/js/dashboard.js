/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 97.23476297968398, "KoPercent": 2.765237020316027};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8408764367816092, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "\u0432\u0445\u043E\u0434"], "isController": true}, {"data": [1.0, 500, 1500, "\u043A\u043B\u0438\u0435\u043D\u0442\u044B_http"], "isController": false}, {"data": [1.0, 500, 1500, "\u0433\u043E\u0441\u0442\u0435\u0432\u0430\u044F_http_1"], "isController": false}, {"data": [0.6106719367588933, 500, 1500, "\u0433\u043E\u0441\u0442\u0435\u0432\u0430\u044F_http_2"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.5434782608695652, 500, 1500, "\u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439"], "isController": true}, {"data": [1.0, 500, 1500, "\u0432\u0445\u043E\u0434_http"], "isController": false}, {"data": [1.0, 500, 1500, "\u043A\u043B\u0438\u0435\u043D\u0442\u044B"], "isController": true}, {"data": [0.6007905138339921, 500, 1500, "\u0433\u043E\u0441\u0442\u0435\u0432\u0430\u044F"], "isController": true}, {"data": [0.549407114624506, 500, 1500, "\u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439_http_2"], "isController": false}, {"data": [0.9446640316205533, 500, 1500, "\u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439_http_1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1772, 49, 2.765237020316027, 168.6489841986458, 0, 1208, 9.0, 610.0, 662.0, 703.54, 5.881903851452054, 302.09194292030554, 1.9001319548865943], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["\u0432\u0445\u043E\u0434", 254, 0, 0.0, 10.992125984251963, 0, 131, 10.0, 13.0, 14.0, 50.29999999999984, 0.8426136947947042, 18.578508468018832, 0.27375485373685904], "isController": true}, {"data": ["\u043A\u043B\u0438\u0435\u043D\u0442\u044B_http", 253, 0, 0.0, 9.154150197628462, 5, 18, 9.0, 12.0, 13.0, 13.0, 0.8438593389879692, 5.055801188991138, 0.31232684519183623], "isController": false}, {"data": ["\u0433\u043E\u0441\u0442\u0435\u0432\u0430\u044F_http_1", 253, 0, 0.0, 9.335968379446639, 5, 52, 9.0, 12.0, 13.0, 17.220000000000056, 0.8438790417803512, 3.3890731110284653, 0.32387154630827936], "isController": false}, {"data": ["\u0433\u043E\u0441\u0442\u0435\u0432\u0430\u044F_http_2", 253, 0, 0.0, 574.7114624505926, 381, 1208, 576.0, 684.6, 696.9, 838.9400000000003, 0.8419385218488038, 137.5401041337351, 0.2441950595596628], "isController": false}, {"data": ["Debug Sampler", 253, 0, 0.0, 0.13438735177865624, 0, 1, 0.0, 1.0, 1.0, 1.0, 0.8424936479974958, 0.39635626700388615, 0.0], "isController": false}, {"data": ["\u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439", 253, 36, 14.229249011857707, 576.8379446640314, 376, 1316, 591.0, 686.6, 702.5999999999999, 1024.820000000003, 0.8413449547569245, 137.76604702345125, 0.7508914089285654], "isController": true}, {"data": ["\u0432\u0445\u043E\u0434_http", 253, 0, 0.0, 11.03557312252964, 6, 131, 10.0, 13.0, 14.0, 50.44000000000011, 0.8435048459853504, 18.671667666175455, 0.2751275571866279], "isController": false}, {"data": ["\u043A\u043B\u0438\u0435\u043D\u0442\u044B", 253, 0, 0.0, 9.154150197628462, 5, 18, 9.0, 12.0, 13.0, 13.0, 0.8438593389879692, 5.055801188991138, 0.31232684519183623], "isController": true}, {"data": ["\u0433\u043E\u0441\u0442\u0435\u0432\u0430\u044F", 253, 0, 0.0, 584.0474308300394, 391, 1216, 586.0, 694.2, 707.5999999999999, 848.5600000000003, 0.8419049013507083, 140.91575668282812, 0.5672992011054577], "isController": true}, {"data": ["\u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439_http_2", 253, 36, 14.229249011857707, 564.6837944664028, 372, 850, 583.0, 673.6, 695.3, 765.7400000000006, 0.8414288992580128, 137.51734940438973, 0.24404724910120096], "isController": false}, {"data": ["\u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439_http_1", 253, 13, 5.138339920948616, 12.154150197628459, 3, 756, 5.0, 8.0, 14.0, 373.78000000000554, 0.8429792820348787, 0.2629266801693289, 0.5078531079446633], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u0421\\u043F\\u0430\\u0441\\u0438\\u0431\\u043E!\'&lt;br&gt;\\\/", 4, 8.16326530612245, 0.22573363431151242], "isController": false}, {"data": ["Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0421\\u043F\\u0430\\u0441\\u0438\\u0431\\u043E!\'&lt;br&gt;\\\/", 3, 6.122448979591836, 0.16930022573363432], "isController": false}, {"data": ["Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u041E\\u0442\\u043B\\u0438\\u0447\\u043D\\u044B\\u0435 \\u0440\\u0435\\u0431\\u044F\\u0442\\u0430.\'&lt;br&gt;\\\/", 4, 8.16326530612245, 0.22573363431151242], "isController": false}, {"data": ["500", 13, 26.53061224489796, 0.7336343115124153], "isController": false}, {"data": ["Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u041E\\u0442\\u043B\\u0438\\u0447\\u043D\\u044B\\u0435 \\u0440\\u0435\\u0431\\u044F\\u0442\\u0430.\'&lt;br&gt;\\\/", 5, 10.204081632653061, 0.28216704288939054], "isController": false}, {"data": ["Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0420\\u0435\\u043A\\u043E\\u043C\\u0435\\u043D\\u0434\\u0443\\u044E, \\u044D\\u0442\\u043E \\u043B\\u0443\\u0447\\u0448\\u0430\\u044F \\u043A\\u043E\\u043C\\u043F\\u0430\\u043D\\u0438\\u044F \\u043D\\u0430 \\u0441\\u0432\\u0435\\u0442\\u0435\'&lt;br&gt;\\\/", 5, 10.204081632653061, 0.28216704288939054], "isController": false}, {"data": ["Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u0420\\u0435\\u043A\\u043E\\u043C\\u0435\\u043D\\u0434\\u0443\\u044E, \\u044D\\u0442\\u043E \\u043B\\u0443\\u0447\\u0448\\u0430\\u044F \\u043A\\u043E\\u043C\\u043F\\u0430\\u043D\\u0438\\u044F \\u043D\\u0430 \\u0441\\u0432\\u0435\\u0442\\u0435\'&lt;br&gt;\\\/", 8, 16.3265306122449, 0.45146726862302483], "isController": false}, {"data": ["Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u0411\\u043B\\u0430\\u0433\\u043E\\u0434\\u0430\\u0440\\u044E \\u0437\\u0430 \\u043E\\u0442\\u043B\\u0438\\u0447\\u043D\\u0443\\u044E \\u0440\\u0430\\u0431\\u043E\\u0442\\u0443!\'&lt;br&gt;\\\/", 6, 12.244897959183673, 0.33860045146726864], "isController": false}, {"data": ["Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0411\\u043B\\u0430\\u0433\\u043E\\u0434\\u0430\\u0440\\u044E \\u0437\\u0430 \\u043E\\u0442\\u043B\\u0438\\u0447\\u043D\\u0443\\u044E \\u0440\\u0430\\u0431\\u043E\\u0442\\u0443!\'&lt;br&gt;\\\/", 1, 2.0408163265306123, 0.056433408577878104], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1772, 49, "500", 13, "Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u0420\\u0435\\u043A\\u043E\\u043C\\u0435\\u043D\\u0434\\u0443\\u044E, \\u044D\\u0442\\u043E \\u043B\\u0443\\u0447\\u0448\\u0430\\u044F \\u043A\\u043E\\u043C\\u043F\\u0430\\u043D\\u0438\\u044F \\u043D\\u0430 \\u0441\\u0432\\u0435\\u0442\\u0435\'&lt;br&gt;\\\/", 8, "Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u0411\\u043B\\u0430\\u0433\\u043E\\u0434\\u0430\\u0440\\u044E \\u0437\\u0430 \\u043E\\u0442\\u043B\\u0438\\u0447\\u043D\\u0443\\u044E \\u0440\\u0430\\u0431\\u043E\\u0442\\u0443!\'&lt;br&gt;\\\/", 6, "Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u041E\\u0442\\u043B\\u0438\\u0447\\u043D\\u044B\\u0435 \\u0440\\u0435\\u0431\\u044F\\u0442\\u0430.\'&lt;br&gt;\\\/", 5, "Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0420\\u0435\\u043A\\u043E\\u043C\\u0435\\u043D\\u0434\\u0443\\u044E, \\u044D\\u0442\\u043E \\u043B\\u0443\\u0447\\u0448\\u0430\\u044F \\u043A\\u043E\\u043C\\u043F\\u0430\\u043D\\u0438\\u044F \\u043D\\u0430 \\u0441\\u0432\\u0435\\u0442\\u0435\'&lt;br&gt;\\\/", 5], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["\u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439_http_2", 253, 36, "Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u0420\\u0435\\u043A\\u043E\\u043C\\u0435\\u043D\\u0434\\u0443\\u044E, \\u044D\\u0442\\u043E \\u043B\\u0443\\u0447\\u0448\\u0430\\u044F \\u043A\\u043E\\u043C\\u043F\\u0430\\u043D\\u0438\\u044F \\u043D\\u0430 \\u0441\\u0432\\u0435\\u0442\\u0435\'&lt;br&gt;\\\/", 8, "Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u0411\\u043B\\u0430\\u0433\\u043E\\u0434\\u0430\\u0440\\u044E \\u0437\\u0430 \\u043E\\u0442\\u043B\\u0438\\u0447\\u043D\\u0443\\u044E \\u0440\\u0430\\u0431\\u043E\\u0442\\u0443!\'&lt;br&gt;\\\/", 6, "Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u041E\\u0442\\u043B\\u0438\\u0447\\u043D\\u044B\\u0435 \\u0440\\u0435\\u0431\\u044F\\u0442\\u0430.\'&lt;br&gt;\\\/", 5, "Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0420\\u0435\\u043A\\u043E\\u043C\\u0435\\u043D\\u0434\\u0443\\u044E, \\u044D\\u0442\\u043E \\u043B\\u0443\\u0447\\u0448\\u0430\\u044F \\u043A\\u043E\\u043C\\u043F\\u0430\\u043D\\u0438\\u044F \\u043D\\u0430 \\u0441\\u0432\\u0435\\u0442\\u0435\'&lt;br&gt;\\\/", 5, "Test failed: text expected to contain \\\/&lt;b&gt;Procter&amp;Gamble&lt;\\\/b&gt;: \'\\u0421\\u043F\\u0430\\u0441\\u0438\\u0431\\u043E!\'&lt;br&gt;\\\/", 4], "isController": false}, {"data": ["\u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439_http_1", 253, 13, "500", 13, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
