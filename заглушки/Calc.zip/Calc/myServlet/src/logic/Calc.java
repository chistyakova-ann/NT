package logic;

public class Calc {
private double a;
private double b;
private String math;

public Calc(double a, String math, double b ) {
	this.a=a;
	this.b=b;
	this.math=math;	
}
public void setA(double a) {
	this.a=a;
}
public double getA() {
	return a;
	}
public void setB(double b) {
	this.b=b;
}
public double getB() {
	return b;
	}
public void setMath(String math) {
	this.math=math;
}
public String getMath() {
	return math;
	}

}
