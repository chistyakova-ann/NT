package logic;

public class Res {
	private double result;
	public Res(double res ) {
	this.result=res;
	}
public void setResult(double result) {
this.result=result;
}
public double getResult() {
return result;
}
}