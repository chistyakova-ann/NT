package ru.appline;

import logic.Calc;
import logic.Res;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

@WebServlet(urlPatterns="/calculate")
public class ServletCalc extends HttpServlet {

	Gson gson=new GsonBuilder().setPrettyPrinting().create();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		StringBuffer jb= new StringBuffer();
		String line;
		try {
			BufferedReader reader= request.getReader();
			while ((line=reader.readLine())!=null) {
				jb.append(line);
			}
		}catch(Exception e) {
			System.out.println("Error");
		}
		
		JsonObject jobj=gson.fromJson(String.valueOf(jb),JsonObject.class);
		request.setCharacterEncoding("UTF-8");
		
		double a=jobj.get("a").getAsDouble();
		double b=jobj.get("b").getAsDouble();
		String math=jobj.get("math").getAsString();
		PrintWriter pw=response.getWriter();
		response.setContentType("application/json,charset=utf-8");
		if(math.equals("*"))
		{ 
			Res result=new Res(a*b);
			pw.print(gson.toJson(result));		
		}else if(math.equals("+")) {
			Res result=new Res((a+b));
			pw.print(gson.toJson(result));
		}else if(math.equals("-")){ 
			Res result=new Res((a-b));
			pw.print(gson.toJson(result));
			}else if(math.equals("/")) {

/*			try {				
				c=a/b;
				pw.print(gson.toJson("Answer")+": "+gson.toJson(c));
			}catch(ArithmeticException e) {
			}*/
	
			if(b==0) {pw.print(gson.toJson("Error"));}
			else {
				Res result=new Res(a/b);
				pw.print(gson.toJson(result));
		}
			}
			else {pw.print(gson.toJson(" Error"));}

	}
	
}
