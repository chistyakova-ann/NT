package ru.appline.controller;

import java.util.Map;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ru.appline.logic.ModelSide;
import ru.appline.logic.Side;

@RestController
public class Controller {
	private static final ModelSide modelSide=ModelSide.getInstance();

	@PostMapping(value="/degree", consumes="application/json",produces="application/json")
	public Side answer(@RequestBody Map<String,Integer> degree) {

		if(((degree.get("degree")>=0)&&(degree.get("degree")<=22))||((degree.get("degree")>=338)&&(degree.get("degree")<=359))) {
				return modelSide.getFromList(1);
			}else if((degree.get("degree")>=23)&&(degree.get("degree")<=67)) {
				return modelSide.getFromList(2);
	}else if((degree.get("degree")>=68)&&(degree.get("degree")<=112)) {
		return modelSide.getFromList(3);}
	else if((degree.get("degree")>=113)&&(degree.get("degree")<=157)) {
		return modelSide.getFromList(4);}
	else if((degree.get("degree")>=158)&&(degree.get("degree")<=202)) {
		return modelSide.getFromList(5);}
	else if((degree.get("degree")>=203)&&(degree.get("degree")<=247)) {
		return modelSide.getFromList(6);}
	else if((degree.get("degree")>=248)&&(degree.get("degree")<=292)) {
		return modelSide.getFromList(7);}
	else if((degree.get("degree")>=293)&&(degree.get("degree")<=337)) {
		return modelSide.getFromList(8);}
	else 	return modelSide.getFromList(9);
	}
}