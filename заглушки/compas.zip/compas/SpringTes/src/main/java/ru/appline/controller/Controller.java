package ru.appline.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.appline.logic.ModelSide;
import ru.appline.logic.ModelSideDegree;
import ru.appline.logic.Side;

@RestController
public class Controller {
	private static final ModelSide modelSide=ModelSide.getInstance();
	private static final ModelSideDegree modelSideDegree=ModelSideDegree.getInstance();
	//private static final ModelDegree modelDegree=ModelDegree.getInstance();

	private static final AtomicInteger newId= new AtomicInteger(1);
	/*@PostMapping(value="/degree", consumes="application/json",produces="application/json")
	public Side answer(@RequestBody Map<String,Integer> degree) {

		if(((degree.get("degree")>=0)&&(degree.get("degree")<=22))||((degree.get("degree")>=338)&&(degree.get("degree")<=359))) {
				return modelSide.getFromList(1);
			}else if((degree.get("degree")>=23)&&(degree.get("degree")<=67)) {
				return modelSide.getFromList(2);
	}else if((degree.get("degree")>=68)&&(degree.get("degree")<=112)) {
		return modelSide.getFromList(3);}
	else if((degree.get("degree")>=113)&&(degree.get("degree")<=157)) {
		return modelSide.getFromList(4);}
	else if((degree.get("degree")>=158)&&(degree.get("degree")<=202)) {
		return modelSide.getFromList(5);}
	else if((degree.get("degree")>=203)&&(degree.get("degree")<=247)) {
		return modelSide.getFromList(6);}
	else if((degree.get("degree")>=248)&&(degree.get("degree")<=292)) {
		return modelSide.getFromList(7);}
	else if((degree.get("degree")>=293)&&(degree.get("degree")<=337)) {
		return modelSide.getFromList(8);}
	else 	return modelSide.getFromList(9);
	}*/

@PostMapping(value="/init", consumes="application/json",produces="application/json")
public Map<Integer,Side> init(@RequestBody Map<Side,String> degree) {
	
	Set<Side> keys = degree.keySet();//все ключи т,е все стороны
    Collection<String> values = degree.values();//градусы
   
    ArrayList<Side> key=new ArrayList<Side>(keys.size());
    ArrayList<String> value=new ArrayList<String>(keys.size());
    ArrayList<Side> sides=new ArrayList<Side>(keys.size());

    value.addAll(values);
    for(Side x:keys) {key.add(x);}
    for(int i=0;i<keys.size();i++) {
    	sides.add(i, key.get(i));
    	}
    for(int i=0;i<keys.size();i++) {
        modelSideDegree.add(sides.get(i), value.get(i));
        }

    for(int i=0;i<keys.size();i++) 
    {modelSide.add(i,sides.get(i));}
    
	for(int i=0;i<keys.size();i++) {
	    String[] subStr;
	    String delimeter = "-"; // Разделитель
	    subStr = value.get(i).split(delimeter);
	    }    
    
    
    return modelSide.getAll();
}	
@PostMapping(value="/degree", consumes="application/json",produces="application/json")
public Side answer(@RequestBody Map<String,Integer> degree) {
	int deg=degree.get("Degree"); 
    	for(int i=0;i<modelSide.getAll().size();) {
	    String delimeter = "-"; 
	    String[] subStr =modelSideDegree.getAll().get(modelSide.getFromList(i)).split(delimeter);
	    	
	    Integer[] a= {1,1};
	    	
	    for(int j=0;j<2;j++) {
	    	 a[j] =Integer.parseInt(subStr[j]);}

	    if(deg>=a[0]&&deg<=a[1])	{
	    	return modelSide.getFromList(i);
	    }
	    i++;
    	}
 return modelSide.getFromList(404);
		
}
}