package ru.appline.logic;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ModelSide implements Serializable{
	private static final ModelSide instance= new ModelSide();
	private final Map<Integer,Side> model;
	public ModelSide() {
		model=new HashMap<Integer,Side>();
		model.put(1,new Side("North"));
		model.put(2,new Side("North-East"));
		model.put(3,new Side("East"));
		model.put(4,new Side("South-East"));
		model.put(5,new Side("South"));
		model.put(6,new Side("South-West"));
		model.put(7,new Side("West"));
		model.put(8,new Side("North-West"));
		model.put(9,new Side("Error"));

	
	}
	public static ModelSide getInstance() {
		return instance;
	}
	public Side getFromList(int id) {
		return model.get(id);
	}
	public Map<Integer,Side> getAll(){
		return model;
	}
}
