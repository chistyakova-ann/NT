package ru.appline.logic;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ModelSide implements Serializable{
	private static final ModelSide instance= new ModelSide();
	private final Map<Integer,Side> model;
	public ModelSide() {
		model=new HashMap<Integer,Side>();
		model.put(404, new Side("Error"));
	}

	public static ModelSide getInstance() {
		return instance;
	}
	public Side getFromList(int id) {
		return model.get(id);
	}
    public void add(Integer i,Side str1) {
    	model.put(i, str1);
 
    }
	public Map<Integer,Side> getAll(){
		return model;
	}
}
