package ru.appline.logic;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ModelSideDegree implements Serializable{
	private static final ModelSideDegree instance= new ModelSideDegree();
	private final Map<Side,String> model;
	public ModelSideDegree() {
		model=new HashMap<Side,String>();

	}

	public static ModelSideDegree getInstance() {
		return instance;
	}
	public void add(Side side,String degree) {
		model.put(side,degree);
	}
	/*public Side getFromList(int id) {
		return model.get(id);
	}*/

	public Map<Side,String> getAll(){
		return model;
	}
}
