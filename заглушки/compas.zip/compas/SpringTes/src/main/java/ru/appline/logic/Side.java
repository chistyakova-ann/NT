package ru.appline.logic;

public class Side {
	private String side;
	
	public Side(String side) {
		this.side=side;
	}

	public void setSide(String side) {
		this.side=side;
	}
	public String getSide() {
		return side;
		}


}
