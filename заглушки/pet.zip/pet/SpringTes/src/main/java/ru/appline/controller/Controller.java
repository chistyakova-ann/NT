package ru.appline.controller;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ru.appline.logic.Messange;
import ru.appline.logic.Pet;
import ru.appline.logic.PetModel;
import ru.appline.logic.modelMes;

@RestController
public class Controller {
	private static final PetModel petModel=PetModel.getInstance();
	private static final modelMes modelmes=modelMes.getInstance();

	private static final AtomicInteger newId= new AtomicInteger(1);
	
	@PostMapping(value="/createPet", consumes="application/json",produces="application/json")
	public Messange createPet(@RequestBody Pet pet) {
		petModel.add(pet, newId.getAndIncrement());
		if (newId.intValue()==2) {return modelmes.getFromList(2);
		}else {return modelmes.getFromList(1);}
	}
	@GetMapping(value="/getAll", produces="application/json")
	public Map<Integer,Pet> getAll() {
		return petModel.getAll();
	}

	@GetMapping(value="/getPet",consumes="application/json", produces="application/json")
	public Pet getPet(@RequestBody Map<String,Integer> id) {
		return petModel.getFromList(id.get("id"));
	}

	@DeleteMapping(value="/deletePet", consumes="application/json",produces="application/json")
	public Messange deletePet(@RequestBody Map<String,Integer> id) {
		if(id.get("id")>0) {
			petModel.delete(id.get("id"));
			return modelmes.getFromList(4);	
				} else if(id.get("id")<=0){return modelmes.getFromList(3);
			}else{return modelmes.getFromList(5);
			}
	}
	@PutMapping(value="/putPet", consumes="application/json",produces="application/json")
	public Map<Integer,Pet> putPet(@RequestBody Map<String,String> str) {
		int id=Integer.parseInt(str.get("id"));
		int age=Integer.parseInt(str.get("age"));

		petModel.getAll().get(id).setName(str.get("name"));
		petModel.getAll().get(id).setType(str.get("type"));
		petModel.getAll().get(id).setAge(age);
		return petModel.getAll();
	}

}
