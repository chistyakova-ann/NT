package ru.appline.logic;

public class Messange {
	String mes;
	
	public Messange() {
		super();	
	}
	public Messange(String mes) {
		this.mes=mes;
	}
	public void setMes(String mes ) {
		this.mes=mes;
	}
	public String getMes() {
		return mes;
		}
}
