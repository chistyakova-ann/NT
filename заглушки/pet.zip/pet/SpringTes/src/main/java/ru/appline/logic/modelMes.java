package ru.appline.logic;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


public class modelMes implements Serializable{
	private static final modelMes instance= new modelMes();
	private final Map<Integer,Messange> model;
	public modelMes() {
		model=new HashMap<Integer,Messange>();
		model.put(1, new Messange("You create new pet"));
		model.put(2, new Messange("You create first pet!"));
		model.put(3, new Messange("Not pet:("));
		model.put(4, new Messange("Pet deleted!!!"));
		model.put(5, new Messange("Enter correct data"));


}
	public static modelMes getInstance() {
		return instance;
	}
/*	public void add(Messange mes, int id) {
		model.put(id, mes);
	}*/
	public Messange getFromList(int id) {
		return model.get(id);
	}
	public Map<Integer,Messange> getAll(){
		return model;
	}

}
